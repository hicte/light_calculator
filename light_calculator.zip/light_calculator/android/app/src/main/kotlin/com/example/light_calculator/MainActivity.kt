package com.example.light_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
